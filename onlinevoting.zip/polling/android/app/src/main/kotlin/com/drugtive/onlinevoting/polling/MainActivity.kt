package com.drugtive.onlinevoting.polling

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
