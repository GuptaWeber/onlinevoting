import 'package:flutter/material.dart';
import 'package:polling/ManagePositions.dart';
import 'package:polling/Widgets/my_header_drawer.dart';
import 'package:polling/login.dart';
import 'package:polling/main.dart';
import 'package:polling/screens/ManageCandidates.dart';

class MyDrawer extends StatefulWidget {
  MyDrawer(this.jwt, this.payload);
  final String jwt;
  final Map<String, dynamic> payload;
  @override
  _MyDrawerState createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  @override
  Widget build(BuildContext context) {
    print(storage.read(key: "jwt"));
    return Drawer(
      child: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              MyHeaderDrawer(widget.jwt, widget.payload),
              MyDrawerList(),
            ],
          ),
        ),
      ),
    );
  }

  Widget MyDrawerList() {
    return Container(
      padding: EdgeInsets.only(top: 15),
      child: Column(
        children: [
          menuItem(),
          Divider(),
          manageAdmins(),
          Divider(),
          managePositions(),
          Divider(),
          manageCandidates(),
          Divider(),
          checkResults(),
          Divider(),
          updateProfile(),
          Divider(),
          logoutScreen(),
          Divider(),
        ],
      ),
    );
  }

  Widget menuItem() {
    return Material(
      child: InkWell(
        onTap: () {},
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Row(
            children: [
              Expanded(
                  child: Icon(
                Icons.dashboard_outlined,
                size: 20,
                color: Colors.black,
              )),
              Expanded(
                flex: 3,
                child: Text(
                  "Dashboard",
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget manageAdmins() {
    return Material(
      child: InkWell(
        onTap: () {},
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Row(
            children: [
              Expanded(
                  child: Icon(
                    Icons.supervised_user_circle_rounded,
                    size: 20,
                    color: Colors.black,
                  )),
              Expanded(
                flex: 3,
                child: Text(
                  "Manage Admins",
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget managePositions() {
    return Material(
      child: InkWell(
        onTap: () {
          Route route = MaterialPageRoute(builder: (c) => ManagePositions(widget.jwt, widget.payload));

          Navigator.push(
              context,
              route
          );
        },
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Row(
            children: [
              Expanded(
                  child: Icon(
                    Icons.edit,
                    size: 20,
                    color: Colors.black,
                  )),
              Expanded(
                flex: 3,
                child: Text(
                  "Manage Positions",
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget manageCandidates() {
    return Material(
      child: InkWell(
        onTap: () {

          Route route = MaterialPageRoute(builder: (c) => ManageCandidates(widget.jwt, widget.payload));

          Navigator.push(
              context,
              route
          );
        },
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Row(
            children: [
              Expanded(
                  child: Icon(
                    Icons.person_add,
                    size: 20,
                    color: Colors.black,
                  )),
              Expanded(
                flex: 3,
                child: Text(
                  "Manage Candidates",
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget checkResults() {
    return Material(
      child: InkWell(
        onTap: () {},
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Row(
            children: [
              Expanded(
                  child: Icon(
                    Icons.poll,
                    size: 20,
                    color: Colors.black,
                  )),
              Expanded(
                flex: 3,
                child: Text(
                  "Check Results",
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget updateProfile() {
    return Material(
      child: InkWell(
        onTap: () {},
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Row(
            children: [
              Expanded(
                  child: Icon(
                    Icons.person,
                    size: 20,
                    color: Colors.black,
                  )),
              Expanded(
                flex: 3,
                child: Text(
                  "Profile",
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget logoutScreen() {
    return Material(
      child: InkWell(
        onTap: () {
          _logout();
          Route route = MaterialPageRoute(builder: (c) => LoginPage());

          Navigator.push(
              context,
              route
          );
        },
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Row(
            children: [
              Expanded(
                  child: Icon(
                    Icons.exit_to_app,
                    size: 20,
                    color: Colors.black,
                  )),
              Expanded(
                flex: 3,
                child: Text(
                  "Logout",
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _logout() async {
    /// Method to Logout the User
    print("Logout ");
    try {
      // signout code
      await storage.deleteAll();
    } catch (e) {
      print(e.toString());
    }
  }

}
